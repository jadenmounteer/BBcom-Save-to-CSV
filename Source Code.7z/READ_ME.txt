___How to make changes to this program___
1. Download Python3, if not already installed on your PC.
2. Using the pip command in the terminal, type: pip install pandas, if not already installed on your PC.
3. Using the pip command, type: pip3 install openpyxl, if not already installed on your PC.
4. Using the pip command, type: pip install pyinstaller, if not already installed on your PC.
5. Once the above modules are installed, make your changes to the save_to_csv.py file, found in the python folder.
6. Test your changes to make sure they work by running your program. To run your program, type: python save_to_csv.py into your terminal while 
in the directory containing the file.
7. To download program as an application, enter the directory containing the save_to_csv.spec file.
8. Once in the directory, type the following command into the terminal: pyinstaller -F save_to_csv.spec 
9. Once the download is complete, your changes can be found in the dist folder. Feel free to move it to wherever you like and even rename it.

___INSTRUCTIONS___
1. Make sure the bestbuy.com orders you are wanting to print are in the New Order queue in SalesPad.
2. To run the program, open the save_to_csv.exe file. Alternatively, you can hold shift and right click and click on 'open powershell window'.
While in the powershell window, type the following command to run the program: ./save_to_csv.exe
3. DO NOT OPEN THE BestBuy.com batch print.csv file after running the program. Your leading zeros from your zip codes will be deleted.
4. If you open the file, run the program again to fix the leading zeros.
5. Go to the following website https://www.ups.com/uis/create?loc=en_US&ActionOriginPair=BatchImportPage___StartSession and follow the prompts
to print your labels.

___FUTURE CHANGES TO MAKE___
o Maybe have the program open the website for you. Maybe include prompts.
