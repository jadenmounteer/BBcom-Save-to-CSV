"""
File: save_to_csv.py
Author: Jaden Mounteer

This program takes the data in the UPS Upload Data.xlsx file,
refreshes it, and saves it into a CSV file called BestBuy.com Batch Print.csv.
"""
# Imports the pandas library to work with datasets and csv files.
# Remember to install this library by typing pip3 install pandas into 
# the terminal.
import pandas as pd
import xlrd
import openpyxl
import yaml
from sqlalchemy import create_engine
import urllib
# Also install pyodbc in pip
# Also intall sqlalchemy using pip
# Imports the webbrowser library so we can navigate to websites
import webbrowser




# Creates the main() function.
def main():
    """
    Opens up the UPS Upload Data file,
    refreshes it, and then saves it.
    Closes the file.
    Reads the file, and then transfers the dataset
    to the BestBuy.com Batch Print.csv file.
    """
    # opens the SQL query.
    print("Opening SQL query.")
    with open(r'sql_query.yml') as file:
        config = yaml.load(file, Loader=yaml.FullLoader)
 
    params = urllib.parse.quote_plus("DRIVER={SQL Server};"
                 "SERVER=gp-server;"
                 "DATABASE=[Name of database];"
                 "Trusted_Connection=yes;")
    engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params) 
    
    # Reads the sql query into the df variable.
    print("Reading SQL query.")
    df = pd.read_sql(con=engine, sql = config["sql"])
    

    # Writes the dataframe to the csv file.
    print("Writing to csv file.")
    df.to_csv("BestBuy.com Batch Print.csv", index=False, index_label=False)

    # Counts the number of orders.
    number_of_orders = len(df)

    # If there are no orders in the dataframe.
    if number_of_orders <= 0:
        #Prints a message to the user.
        print("WARNING: There are no orders needing to be printed.")
        print("Please make sure the orders you need to print are in")
        print("the New Order queue in SalesPad.")
        input("Press ENTER to close program.")
    
    # Or, if there were orders to print
    else: 
        # prints the number of orders printed.
        print("There are " + str(number_of_orders) + " to be printed.")

        # Opens the ups.com website.
        print("Opening UPS.com Batch File Shipping.")
        webbrowser.open("www.ups.com/uis/create?loc=en_US&ActionOriginPair=BatchImportPage___StartSession")

        print("The data has been saved to the BestBuy.com Batch Print.csv file.")
        #input("Press ENTER to close program.")


# Runs the main() function.
if __name__ == "__main__":
    main()
